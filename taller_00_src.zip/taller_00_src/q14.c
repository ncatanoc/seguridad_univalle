#include<stdio.h>

struct {
  char s[3];
  int i;
} x;

void main()
{
  printf("%ld\t", (char *)&x.i - x.s);
  printf("%lu\n", sizeof(x) - sizeof(x.s) - sizeof(x.i));
}
