#include<stdio.h>
#include<string.h>

int main()
{
  char s[10];
  scanf("%10c", s);
  printf("%zu", strlen(s)); 
}


