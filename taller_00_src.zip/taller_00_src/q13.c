#include<stdio.h>

struct Date
{
  int day;
  int month;
  int year;
};

int main()
{
  struct Date d = { 1, 1, 2020 };
  
  struct Date *d2;
  d2 = &d;
  
  printf("%d/%d/%d\n", d2->day, d2->month, d2->year);
  return 0;
}
