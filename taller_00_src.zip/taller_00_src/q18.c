int main()
{
    char s1[5] = "Hello";
    char s2[5] = "cStr";

    
    return 0;
}
