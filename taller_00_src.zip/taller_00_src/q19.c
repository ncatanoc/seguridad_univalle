#include <stdlib.h>
#include <stdio.h>

int* f() {
  int* p = malloc(sizeof(int));
  (*p) = 33;
  return p;
}

int main(void) {
  int* p = f();
  printf("%i\n",(*p));
  return 0;
}

